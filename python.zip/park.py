my_dict = {}

person = {
    'firstname' : "dongkyu",
    'lastname' : 'kim',
     'age' : 26
  }
print(person)

while person:
    if 